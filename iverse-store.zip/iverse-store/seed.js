require("dotenv").config();
const mongoose = require("mongoose");
const { Product, Coupon } = require("./src/models");

const products = [
  { name: "Aero Wireless Headphones", slug: "aero-wireless-headphones", sku: "IV-TECH-001", category: "Tech", price: 2499, compareAtPrice: 3299, stock: 18, description: "Immersive everyday listening in a clean, modern silhouette. Sample product; confirm supplier specifications before selling.", images: ["https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=85"] },
  { name: "Luma Desk Lamp", slug: "luma-desk-lamp", sku: "IV-HOME-001", category: "Home & Desk", price: 1899, compareAtPrice: 2299, stock: 12, description: "A refined accent for focused work and calm evenings. Sample product; specifications must be verified.", images: ["https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=900&q=85"] },
  { name: "Forma Everyday Watch", slug: "forma-everyday-watch", sku: "IV-LIFE-001", category: "Lifestyle", price: 3199, stock: 8, description: "A versatile, minimalist-inspired timepiece concept. Sample product; do not imply a luxury watchmaker affiliation.", images: ["https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=900&q=85"] },
  { name: "Orbit Travel Organizer", slug: "orbit-travel-organizer", sku: "IV-TRAVEL-001", category: "Travel", price: 999, compareAtPrice: 1299, stock: 35, description: "Keep everyday travel essentials neatly arranged. Sample product; verify dimensions and materials with supplier.", images: ["https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=900&q=85"] },
  { name: "Noir Crossbody Bag", slug: "noir-crossbody-bag", sku: "IV-STYLE-001", category: "Accessories", price: 1799, stock: 15, description: "A clean everyday carry silhouette for a streamlined wardrobe. Sample product; verify material and sizing.", images: ["https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=900&q=85"] },
  { name: "Studio Wireless Speaker", slug: "studio-wireless-speaker", sku: "IV-TECH-002", category: "Tech", price: 2199, compareAtPrice: 2699, stock: 20, description: "Compact audio for desks and small spaces. Sample product; confirm battery, connectivity and warranty details.", images: ["https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?auto=format&fit=crop&w=900&q=85"] },
  { name: "Arc Sunglasses", slug: "arc-sunglasses", sku: "IV-STYLE-002", category: "Accessories", price: 1299, stock: 24, description: "A versatile accessory with a clean profile. Sample product; verify UV protection claims before listing.", images: ["https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=900&q=85"] },
  { name: "Terra Ceramic Vase", slug: "terra-ceramic-vase", sku: "IV-HOME-002", category: "Home & Desk", price: 1499, stock: 10, description: "A sculptural decorative accent for curated spaces. Sample product; check fragile-item packaging and shipping.", images: ["https://images.unsplash.com/photo-1578500494198-246f612d3b3d?auto=format&fit=crop&w=900&q=85"] }
];

async function main() {
  if (!process.env.MONGODB_URI) throw new Error("Set MONGODB_URI in .env first.");
  await mongoose.connect(process.env.MONGODB_URI);
  for (const p of products) await Product.updateOne({ slug: p.slug }, { $setOnInsert: p }, { upsert: true });
  await Coupon.updateOne({ code: "WELCOME10" }, { $setOnInsert: { code: "WELCOME10", type: "percent", value: 10, minSubtotal: 500, expiresAt: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000), active: true } }, { upsert: true });
  console.log(`Seeded ${products.length} sample products and WELCOME10 coupon (new records only).`);
  await mongoose.disconnect();
}
main().catch(err => { console.error(err); process.exit(1); });
