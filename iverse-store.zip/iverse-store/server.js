require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");
const session = require("express-session");
const MongoStore = require("connect-mongo");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const mongoSanitize = require("express-mongo-sanitize");
const path = require("path");
const crypto = require("crypto");
const Razorpay = require("razorpay");
const { User, Product, Order, Coupon, Newsletter } = require("./src/models");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === "production";

app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false })); // CSP can be tightened after deployment/CDN choices.
app.use(express.json({ limit: "100kb" }));
app.use(express.urlencoded({ extended: false, limit: "20kb" }));
app.use(mongoSanitize());
app.use(express.static(path.join(__dirname, "public")));
if (isProduction) app.set("trust proxy", 1);

app.use(session({
  name: process.env.SESSION_NAME || "iverse.sid",
  secret: process.env.SESSION_SECRET || "dev-only-change-this-session-secret-32chars",
  resave: false,
  saveUninitialized: false,
  store: process.env.MONGODB_URI ? MongoStore.create({ mongoUrl: process.env.MONGODB_URI }) : undefined,
  cookie: { httpOnly: true, sameSite: "lax", secure: isProduction, maxAge: 1000 * 60 * 60 * 24 * 7 }
}));

const apiLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 180, standardHeaders: true, legacyHeaders: false });
app.use("/api", apiLimiter);

function asyncRoute(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}
function requireAuth(req, res, next) {
  if (!req.session.userId) return res.status(401).json({ error: "Please sign in to continue." });
  next();
}
function requireAdmin(req, res, next) {
  if (!req.session.userId || req.session.role !== "admin") return res.status(403).json({ error: "Administrator access required." });
  next();
}
function safeUser(user) {
  return { id: String(user._id), name: user.name, email: user.email, role: user.role };
}
function validEmail(email) {
  return typeof email === "string" && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && email.length <= 254;
}
function rupees(n) { return Math.round(Number(n) * 100) / 100; }

app.get("/api/health", (req, res) => res.json({
  status: "ok",
  app: "IVERSE",
  database: mongoose.connection.readyState === 1 ? "connected" : "not-connected",
  payments: process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET ? "configured (verify test/live mode in Razorpay dashboard)" : "disabled"
}));

app.get("/api/products", asyncRoute(async (req, res) => {
  const filter = { active: true };
  if (req.query.category && req.query.category !== "all") filter.category = String(req.query.category).slice(0, 80);
  if (req.query.q) {
    const q = String(req.query.q).slice(0, 100);
    filter.$or = [{ name: { $regex: q.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), $options: "i" } },
      { description: { $regex: q.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), $options: "i" } }];
  }
  let query = Product.find(filter).select("-supplierCost -supplierName -supplierSku");
  if (req.query.sort === "price-asc") query = query.sort({ price: 1 });
  else if (req.query.sort === "price-desc") query = query.sort({ price: -1 });
  else query = query.sort({ createdAt: -1 });
  const products = await query.limit(100).lean();
  res.json({ products });
}));

app.get("/api/products/:slug", asyncRoute(async (req, res) => {
  const product = await Product.findOne({ slug: req.params.slug, active: true }).select("-supplierCost -supplierName -supplierSku").lean();
  if (!product) return res.status(404).json({ error: "Product not found." });
  res.json({ product });
}));

app.post("/api/auth/register", rateLimit({ windowMs: 15 * 60 * 1000, limit: 8 }), asyncRoute(async (req, res) => {
  const name = String(req.body.name || "").trim();
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  if (name.length < 2 || name.length > 80) return res.status(400).json({ error: "Name must be 2–80 characters." });
  if (!validEmail(email)) return res.status(400).json({ error: "Enter a valid email address." });
  if (password.length < 10 || password.length > 128) return res.status(400).json({ error: "Password must be 10–128 characters." });
  if (await User.exists({ email })) return res.status(409).json({ error: "An account with this email already exists." });
  const bcrypt = require("bcryptjs");
  let role = "customer";
  // Only an explicitly configured email can be bootstrapped as admin. Protect .env and configure before first registration.
  if (process.env.BOOTSTRAP_ADMIN_EMAIL && email === process.env.BOOTSTRAP_ADMIN_EMAIL.trim().toLowerCase()) role = "admin";
  const user = await User.create({ name, email, passwordHash: await bcrypt.hash(password, 12), role });
  req.session.userId = String(user._id);
  req.session.role = user.role;
  res.status(201).json({ user: safeUser(user) });
}));

app.post("/api/auth/login", rateLimit({ windowMs: 15 * 60 * 1000, limit: 10 }), asyncRoute(async (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  const user = await User.findOne({ email });
  const bcrypt = require("bcryptjs");
  if (!user || !(await bcrypt.compare(password, user.passwordHash))) return res.status(401).json({ error: "Email or password is incorrect." });
  req.session.regenerate(err => {
    if (err) return res.status(500).json({ error: "Could not start a secure session." });
    req.session.userId = String(user._id);
    req.session.role = user.role;
    res.json({ user: safeUser(user) });
  });
}));

app.get("/api/auth/me", asyncRoute(async (req, res) => {
  if (!req.session.userId) return res.json({ user: null });
  const user = await User.findById(req.session.userId);
  if (!user) { req.session.destroy(() => {}); return res.json({ user: null }); }
  res.json({ user: safeUser(user) });
}));
app.post("/api/auth/logout", (req, res) => req.session.destroy(() => {
  res.clearCookie(process.env.SESSION_NAME || "iverse.sid");
  res.json({ ok: true });
}));

app.get("/api/wishlist", requireAuth, asyncRoute(async (req, res) => {
  const user = await User.findById(req.session.userId).populate({ path: "wishlist", match: { active: true }, select: "-supplierCost -supplierName -supplierSku" });
  res.json({ products: user.wishlist || [] });
}));
app.post("/api/wishlist/:productId", requireAuth, asyncRoute(async (req, res) => {
  const product = await Product.findOne({ _id: req.params.productId, active: true });
  if (!product) return res.status(404).json({ error: "Product not found." });
  const user = await User.findById(req.session.userId);
  const exists = user.wishlist.some(id => String(id) === String(product._id));
  user.wishlist = exists ? user.wishlist.filter(id => String(id) !== String(product._id)) : [...user.wishlist, product._id];
  await user.save();
  res.json({ saved: !exists });
}));

app.get("/api/orders", requireAuth, asyncRoute(async (req, res) => {
  const orders = await Order.find({ user: req.session.userId }).sort({ createdAt: -1 }).select("-paymentDetails").lean();
  res.json({ orders });
}));

app.post("/api/coupons/validate", asyncRoute(async (req, res) => {
  const code = String(req.body.code || "").trim().toUpperCase();
  const subtotal = rupees(Math.max(0, Number(req.body.subtotal) || 0));
  const coupon = await Coupon.findOne({ code, active: true, expiresAt: { $gt: new Date() } });
  if (!coupon || subtotal < coupon.minSubtotal) return res.status(400).json({ error: "Coupon is invalid or the minimum order value is not met." });
  const discount = coupon.type === "percent" ? subtotal * coupon.value / 100 : coupon.value;
  res.json({ code, discount: rupees(Math.min(subtotal, discount)) });
}));

app.post("/api/newsletter", asyncRoute(async (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  if (!validEmail(email)) return res.status(400).json({ error: "Enter a valid email address." });
  await Newsletter.updateOne({ email }, { $setOnInsert: { email } }, { upsert: true });
  res.json({ ok: true, message: "Thanks for joining the IVERSE list." });
}));

app.post("/api/checkout", requireAuth, asyncRoute(async (req, res) => {
  const items = Array.isArray(req.body.items) ? req.body.items : [];
  if (!items.length || items.length > 30) return res.status(400).json({ error: "Your cart is empty or contains too many items." });
  const ids = [...new Set(items.map(i => String(i.productId || "")))];
  const products = await Product.find({ _id: { $in: ids }, active: true }).lean();
  const byId = new Map(products.map(p => [String(p._id), p]));
  const orderItems = [];
  let subtotal = 0;
  for (const item of items) {
    const p = byId.get(String(item.productId));
    const quantity = Number(item.quantity);
    if (!p || !Number.isInteger(quantity) || quantity < 1 || quantity > 10) return res.status(400).json({ error: "One or more cart items are invalid." });
    if (p.stock < quantity) return res.status(409).json({ error: `${p.name} does not have enough stock.` });
    orderItems.push({ product: p._id, name: p.name, sku: p.sku, price: p.price, quantity });
    subtotal += p.price * quantity;
  }
  subtotal = rupees(subtotal);
  const shipping = subtotal >= 1999 ? 0 : 99;
  const total = rupees(subtotal + shipping);
  const address = req.body.address || {};
  const required = ["fullName", "phone", "line1", "city", "state", "postalCode"];
  for (const key of required) {
    const value = String(address[key] || "").trim();
    if (!value || value.length > 120) return res.status(400).json({ error: `Please enter a valid ${key}.` });
  }
  if (!/^[6-9]\d{9}$/.test(String(address.phone).replace(/\D/g, ""))) return res.status(400).json({ error: "Enter a valid 10-digit Indian mobile number." });
  if (!/^\d{6}$/.test(String(address.postalCode))) return res.status(400).json({ error: "Enter a valid 6-digit PIN code." });

  let payment = { provider: "manual-test", status: "pending", amountPaise: Math.round(total * 100) };
  let paymentOrder = null;
  if (process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET) {
    const rzp = new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET });
    paymentOrder = await rzp.orders.create({ amount: Math.round(total * 100), currency: "INR", receipt: `iv_${Date.now()}` });
    payment = { provider: "razorpay", status: "pending", amountPaise: paymentOrder.amount, providerOrderId: paymentOrder.id };
  }
  const order = await Order.create({
    user: req.session.userId, items: orderItems, address: {
      fullName: String(address.fullName).trim(), phone: String(address.phone).replace(/\D/g, ""),
      line1: String(address.line1).trim(), line2: String(address.line2 || "").trim().slice(0, 120),
      city: String(address.city).trim(), state: String(address.state).trim(), postalCode: String(address.postalCode)
    }, subtotal, shipping, total, payment
  });
  res.status(201).json({
    order: { id: String(order._id), orderNumber: order.orderNumber, subtotal, shipping, total, status: order.status, paymentStatus: order.payment.status },
    payment: paymentOrder ? { provider: "razorpay", keyId: process.env.RAZORPAY_KEY_ID, orderId: paymentOrder.id, amount: paymentOrder.amount, currency: paymentOrder.currency } : { provider: "manual-test", message: "No payment provider configured. This order is pending and is NOT paid." }
  });
}));

app.post("/api/payments/razorpay/verify", requireAuth, asyncRoute(async (req, res) => {
  const { razorpay_order_id, razorpay_payment_id, razorpay_signature, orderId } = req.body;
  if (!process.env.RAZORPAY_KEY_SECRET) return res.status(503).json({ error: "Payment provider is not configured." });
  if (![razorpay_order_id, razorpay_payment_id, razorpay_signature, orderId].every(v => typeof v === "string" && v.length < 200)) return res.status(400).json({ error: "Invalid payment verification payload." });
  const expected = crypto.createHmac("sha256", process.env.RAZORPAY_KEY_SECRET).update(`${razorpay_order_id}|${razorpay_payment_id}`).digest("hex");
  const a = Buffer.from(expected);
  const b = Buffer.from(razorpay_signature);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return res.status(400).json({ error: "Payment signature verification failed." });
  const order = await Order.findOne({ _id: orderId, user: req.session.userId, "payment.providerOrderId": razorpay_order_id });
  if (!order) return res.status(404).json({ error: "Order not found." });
  if (order.payment.status !== "paid") {
    order.payment.status = "paid";
    order.payment.paymentId = razorpay_payment_id;
    order.status = "confirmed";
    await order.save();
  }
  res.json({ ok: true, orderNumber: order.orderNumber, status: order.status });
}));

// Razorpay webhooks must use raw body to verify signatures; mount this route before any raw-body middleware changes.
app.post("/api/payments/razorpay/webhook", express.raw({ type: "application/json" }), asyncRoute(async (req, res) => {
  const secret = process.env.RAZORPAY_WEBHOOK_SECRET;
  if (!secret) return res.status(503).send("Webhook secret is not configured.");
  const signature = req.headers["x-razorpay-signature"];
  const expected = crypto.createHmac("sha256", secret).update(req.body).digest("hex");
  if (!signature || expected.length !== signature.length || !crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(signature))) return res.status(400).send("Invalid signature.");
  const event = JSON.parse(req.body.toString("utf8"));
  if (event.event === "payment.captured" && event.payload?.payment?.entity) {
    const paymentEntity = event.payload.payment.entity;
    await Order.findOneAndUpdate({ "payment.providerOrderId": paymentEntity.order_id, "payment.status": { $ne: "paid" } }, {
      $set: { "payment.status": "paid", "payment.paymentId": paymentEntity.id, status: "confirmed" }
    });
  }
  res.json({ received: true });
}));

app.get("/api/account", requireAuth, asyncRoute(async (req, res) => {
  const user = await User.findById(req.session.userId).select("name email createdAt");
  res.json({ user });
}));

// Admin product and order management. No default admin user is created.
app.get("/api/admin/products", requireAdmin, asyncRoute(async (req, res) => {
  res.json({ products: await Product.find().sort({ createdAt: -1 }).lean() });
}));
app.post("/api/admin/products", requireAdmin, asyncRoute(async (req, res) => {
  const payload = validateProduct(req.body);
  const product = await Product.create(payload);
  res.status(201).json({ product });
}));
app.patch("/api/admin/products/:id", requireAdmin, asyncRoute(async (req, res) => {
  const payload = validateProduct(req.body);
  const product = await Product.findByIdAndUpdate(req.params.id, payload, { new: true, runValidators: true });
  if (!product) return res.status(404).json({ error: "Product not found." });
  res.json({ product });
}));
app.delete("/api/admin/products/:id", requireAdmin, asyncRoute(async (req, res) => {
  const product = await Product.findByIdAndUpdate(req.params.id, { active: false }, { new: true });
  if (!product) return res.status(404).json({ error: "Product not found." });
  res.json({ ok: true });
}));
app.get("/api/admin/orders", requireAdmin, asyncRoute(async (req, res) => {
  res.json({ orders: await Order.find().populate("user", "name email").sort({ createdAt: -1 }).limit(200).lean() });
}));
app.patch("/api/admin/orders/:id/status", requireAdmin, asyncRoute(async (req, res) => {
  const allowed = ["pending", "confirmed", "processing", "shipped", "delivered", "cancelled", "refunded"];
  if (!allowed.includes(req.body.status)) return res.status(400).json({ error: "Invalid order status." });
  const order = await Order.findByIdAndUpdate(req.params.id, { status: req.body.status }, { new: true });
  if (!order) return res.status(404).json({ error: "Order not found." });
  res.json({ order });
}));

function validateProduct(body) {
  const name = String(body.name || "").trim();
  const slug = String(body.slug || name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "")).trim();
  const price = Number(body.price), stock = Number(body.stock);
  if (name.length < 2 || name.length > 120) throw Object.assign(new Error("Product name must be 2–120 characters."), { status: 400 });
  if (!/^[a-z0-9-]{2,140}$/.test(slug)) throw Object.assign(new Error("Invalid product slug."), { status: 400 });
  if (!Number.isFinite(price) || price <= 0 || price > 10000000) throw Object.assign(new Error("Invalid product price."), { status: 400 });
  if (!Number.isInteger(stock) || stock < 0 || stock > 1000000) throw Object.assign(new Error("Invalid stock quantity."), { status: 400 });
  const images = Array.isArray(body.images) ? body.images.slice(0, 8).map(x => String(x).slice(0, 1000)) : [];
  return {
    name, slug, description: String(body.description || "").slice(0, 3000),
    category: String(body.category || "Lifestyle").slice(0, 80),
    sku: String(body.sku || `IV-${slug.toUpperCase().slice(0, 24)}`).slice(0, 50),
    price: rupees(price), compareAtPrice: body.compareAtPrice ? rupees(Number(body.compareAtPrice)) : undefined,
    images, stock, active: body.active !== false,
    supplierName: String(body.supplierName || "").slice(0, 120),
    supplierSku: String(body.supplierSku || "").slice(0, 100),
    supplierCost: body.supplierCost == null ? undefined : rupees(Number(body.supplierCost)),
    shippingInfo: String(body.shippingInfo || "Estimated delivery: 5–10 business days").slice(0, 200),
    returnEligible: body.returnEligible !== false,
    variants: Array.isArray(body.variants) ? body.variants.slice(0, 30) : []
  };
}

app.get("/sitemap.xml", (req, res) => {
  res.type("application/xml").send(`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>${process.env.BASE_URL || "http://localhost:3000"}/</loc></url><url><loc>${process.env.BASE_URL || "http://localhost:3000"}/shop.html</loc></url></urlset>`);
});
app.get("/robots.txt", (req, res) => res.type("text/plain").send("User-agent: *\nAllow: /\nDisallow: /api/admin\nSitemap: " + (process.env.BASE_URL || "http://localhost:3000") + "/sitemap.xml\n"));

app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api/")) return next();
  res.sendFile(path.join(__dirname, "public", "index.html"));
});
app.use((err, req, res, next) => {
  console.error(err.message);
  const status = err.status || (err.name === "ValidationError" ? 400 : err.code === 11000 ? 409 : 500);
  res.status(status).json({ error: status >= 500 ? "Something went wrong. Please try again." : err.message });
});

async function start() {
  if (process.env.MONGODB_URI) {
    try { await mongoose.connect(process.env.MONGODB_URI); console.log("MongoDB connected."); }
    catch (e) { console.error("MongoDB connection failed:", e.message); process.exitCode = 1; return; }
  } else {
    console.warn("MONGODB_URI is not set. API database features will not work until MongoDB is configured.");
  }
  app.listen(PORT, () => console.log(`IVERSE running at http://localhost:${PORT}`));
}
if (require.main === module) start();
module.exports = app;
