const mongoose = require("mongoose");
const { Schema } = mongoose;

const productSchema = new Schema({
  name: { type: String, required: true, trim: true, maxlength: 120 },
  slug: { type: String, required: true, unique: true, lowercase: true, trim: true },
  description: { type: String, default: "", maxlength: 3000 },
  category: { type: String, required: true, index: true },
  sku: { type: String, required: true, unique: true },
  price: { type: Number, required: true, min: 0 },
  compareAtPrice: { type: Number, min: 0 },
  images: [{ type: String }],
  stock: { type: Number, default: 0, min: 0 },
  active: { type: Boolean, default: true, index: true },
  supplierName: { type: String, default: "" },
  supplierSku: { type: String, default: "" },
  supplierCost: { type: Number, min: 0 },
  shippingInfo: { type: String, default: "Estimated delivery: 5–10 business days" },
  returnEligible: { type: Boolean, default: true },
  variants: [{ name: String, options: [String] }]
}, { timestamps: true });
productSchema.index({ name: "text", description: "text" });

const userSchema = new Schema({
  name: { type: String, required: true, trim: true, maxlength: 80 },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  passwordHash: { type: String, required: true },
  role: { type: String, enum: ["customer", "admin"], default: "customer" },
  wishlist: [{ type: Schema.Types.ObjectId, ref: "Product" }]
}, { timestamps: true });

const orderSchema = new Schema({
  orderNumber: { type: String, unique: true, index: true },
  user: { type: Schema.Types.ObjectId, ref: "User", required: true, index: true },
  items: [{ product: Schema.Types.ObjectId, name: String, sku: String, price: Number, quantity: Number }],
  address: { fullName: String, phone: String, line1: String, line2: String, city: String, state: String, postalCode: String },
  subtotal: { type: Number, required: true },
  shipping: { type: Number, required: true },
  total: { type: Number, required: true },
  status: { type: String, enum: ["pending", "confirmed", "processing", "shipped", "delivered", "cancelled", "refunded"], default: "pending" },
  payment: {
    provider: String, status: { type: String, enum: ["pending", "paid", "failed", "refunded"], default: "pending" },
    amountPaise: Number, providerOrderId: String, paymentId: String
  },
  trackingNumber: String,
  fulfilment: { type: String, enum: ["unassigned", "pending", "sent-to-supplier", "shipped", "complete"], default: "unassigned" }
}, { timestamps: true });
orderSchema.pre("validate", function(next) {
  if (!this.orderNumber) this.orderNumber = "IV-" + Date.now().toString(36).toUpperCase() + "-" + Math.random().toString(36).slice(2, 7).toUpperCase();
  next();
});

const couponSchema = new Schema({
  code: { type: String, required: true, unique: true, uppercase: true, trim: true },
  type: { type: String, enum: ["percent", "fixed"], required: true },
  value: { type: Number, min: 0, required: true },
  minSubtotal: { type: Number, default: 0 },
  expiresAt: { type: Date, required: true },
  active: { type: Boolean, default: true }
}, { timestamps: true });

const newsletterSchema = new Schema({ email: { type: String, unique: true, required: true, lowercase: true, trim: true } }, { timestamps: true });

module.exports = {
  Product: mongoose.models.Product || mongoose.model("Product", productSchema),
  User: mongoose.models.User || mongoose.model("User", userSchema),
  Order: mongoose.models.Order || mongoose.model("Order", orderSchema),
  Coupon: mongoose.models.Coupon || mongoose.model("Coupon", couponSchema),
  Newsletter: mongoose.models.Newsletter || mongoose.model("Newsletter", newsletterSchema)
};
