const state = {
  products: [], category: "all", sort: "newest", search: "",
  cart: JSON.parse(localStorage.getItem("iverse-cart") || "[]"),
  wishlist: new Set(JSON.parse(localStorage.getItem("iverse-wishlist") || "[]")),
  user: null, authMode: "login", toastTimer: null
};
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const money = n => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(n);
const escapeHtml = value => String(value ?? "").replace(/[&<>"']/g, c => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[c]));
const imageFallback = "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=800&q=80";
async function api(url, options = {}) {
  const response = await fetch(url, { credentials: "same-origin", ...options, headers: { ...(options.body ? { "Content-Type": "application/json" } : {}), ...(options.headers || {}) } });
  let data = {};
  try { data = await response.json(); } catch {}
  if (!response.ok) throw new Error(data.error || "Something went wrong.");
  return data;
}
function showToast(message) {
  const el = $("#toast"); el.textContent = message; el.classList.add("show");
  clearTimeout(state.toastTimer); state.toastTimer = setTimeout(() => el.classList.remove("show"), 2800);
}
function saveCart() { localStorage.setItem("iverse-cart", JSON.stringify(state.cart)); renderCart(); }
function cartProducts() {
  return state.cart.map(line => {
    const p = state.products.find(p => p._id === line.productId);
    return p ? { ...p, quantity: line.quantity } : null;
  }).filter(Boolean);
}
function cartSubtotal() { return cartProducts().reduce((sum, p) => sum + p.price * p.quantity, 0); }
function renderProducts() {
  let products = [...state.products];
  if (state.category !== "all") products = products.filter(p => p.category === state.category);
  if (state.search) products = products.filter(p => `${p.name} ${p.description} ${p.category}`.toLowerCase().includes(state.search.toLowerCase()));
  if (state.sort === "price-asc") products.sort((a,b) => a.price-b.price);
  if (state.sort === "price-desc") products.sort((a,b) => b.price-a.price);
  const grid = $("#products");
  if (!products.length) { grid.innerHTML = '<div class="empty-state">No pieces found. Try another search or category.</div>'; return; }
  grid.innerHTML = products.map(p => {
    const image = p.images?.[0] || imageFallback;
    const sale = p.compareAtPrice && p.compareAtPrice > p.price;
    return `<article class="product-card">
      <div class="product-image-wrap">
        <img class="product-image" src="${escapeHtml(image)}" alt="${escapeHtml(p.name)}" loading="lazy" onerror="this.onerror=null;this.src='${imageFallback}'">
        ${sale ? `<span class="product-tag">Special price</span>` : ""}
        <button class="heart-button ${state.wishlist.has(p._id) ? "saved" : ""}" data-wishlist="${p._id}" aria-label="${state.wishlist.has(p._id) ? "Remove from" : "Add to"} wishlist">${state.wishlist.has(p._id) ? "♥" : "♡"}</button>
        <button class="quick-add" data-add="${p._id}" ${p.stock < 1 ? "disabled" : ""}>${p.stock < 1 ? "Sold out" : "Add to bag +"}</button>
      </div>
      <div class="product-meta"><div class="product-category">${escapeHtml(p.category)}</div><h3 class="product-name">${escapeHtml(p.name)}</h3><div class="product-price">${money(p.price)} ${sale ? `<span class="compare-price">${money(p.compareAtPrice)}</span>` : ""}</div></div>
    </article>`;
  }).join("");
}
function renderCart() {
  const items = cartProducts();
  const count = items.reduce((s,p) => s+p.quantity,0);
  $("#cartCount").textContent = count;
  $("#drawerCount").textContent = `(${count})`;
  $("#cartSubtotal").textContent = money(cartSubtotal());
  $("#shippingProgress").textContent = cartSubtotal() >= 1999 ? "You've unlocked free shipping." : `Add ${money(1999-cartSubtotal())} for free shipping.`;
  $("#cartItems").innerHTML = items.length ? items.map(p => `<div class="cart-line">
    <img src="${escapeHtml(p.images?.[0] || imageFallback)}" alt="${escapeHtml(p.name)}">
    <div><h3>${escapeHtml(p.name)}</h3><p>${money(p.price)}</p><div class="qty-controls"><button data-qty="${p._id}" data-delta="-1" aria-label="Decrease quantity">−</button><span>${p.quantity}</span><button data-qty="${p._id}" data-delta="1" aria-label="Increase quantity" ${p.quantity >= Math.min(10,p.stock) ? "disabled" : ""}>+</button></div></div>
    <button class="remove-line" data-remove="${p._id}" aria-label="Remove ${escapeHtml(p.name)}">×</button>
  </div>`).join("") : '<div class="empty-state">Your bag is waiting for something considered.</div>';
}
function openDrawer() {
  $("#overlay").classList.remove("hidden"); $("#cartDrawer").classList.add("open"); $("#cartDrawer").setAttribute("aria-hidden","false"); document.body.classList.add("modal-open");
}
function closeDrawer() {
  $("#overlay").classList.add("hidden"); $("#cartDrawer").classList.remove("open"); $("#cartDrawer").setAttribute("aria-hidden","true"); document.body.classList.remove("modal-open");
}
function openModal(id) {
  closeDrawer(); $$(".modal").forEach(m => m.classList.add("hidden"));
  $(id).classList.remove("hidden"); $("#overlay").classList.remove("hidden"); document.body.classList.add("modal-open");
}
function closeModal() {
  $$(".modal").forEach(m => m.classList.add("hidden")); $("#overlay").classList.add("hidden"); document.body.classList.remove("modal-open");
}
async function loadProducts() {
  $("#products").innerHTML = '<div class="loading">Curating the collection…</div>';
  try {
    const data = await api("/api/products");
    state.products = data.products;
    renderProducts(); renderCart();
  } catch (error) {
    $("#products").innerHTML = `<div class="empty-state">${escapeHtml(error.message)}<br><small>Start the server and connect MongoDB, then seed sample products.</small></div>`;
  }
}
async function loadUser() {
  try {
    const data = await api("/api/auth/me"); state.user = data.user;
    if (state.user) {
      $(".account-open").textContent = "♙";
      $("#accountTitle").textContent = `Hello, ${state.user.name.split(" ")[0]}`;
      $("#accountContent").innerHTML = `<p>${escapeHtml(state.user.email)}</p><button class="button button-dark full" id="ordersOpen">View my orders</button><button class="button full" id="logoutButton" style="margin-top:8px">Sign out</button><div id="accountExtra"></div>`;
    }
  } catch {}
}
function setAuthMode(mode) {
  state.authMode = mode;
  $("#nameField").classList.toggle("hidden", mode !== "register");
  $("#nameField input").required = mode === "register";
  $("#authSubmit").textContent = mode === "register" ? "Create account" : "Sign in";
  $("#authForm [name=password]").setAttribute("autocomplete", mode === "register" ? "new-password" : "current-password");
  $$(".auth-tabs .pill").forEach(b => b.classList.toggle("active", b.dataset.authTab === mode));
}
async function toggleWishlist(id) {
  if (!state.user) { openModal("#accountModal"); showToast("Sign in to save your wishlist."); return; }
  try {
    const result = await api(`/api/wishlist/${id}`, { method:"POST", body:JSON.stringify({}) });
    if (result.saved) state.wishlist.add(id); else state.wishlist.delete(id);
    localStorage.setItem("iverse-wishlist", JSON.stringify([...state.wishlist])); renderProducts();
    showToast(result.saved ? "Saved to your wishlist." : "Removed from your wishlist.");
  } catch (e) { showToast(e.message); }
}
function openInfo(title, html) {
  $("#infoTitle").textContent = title; $("#infoContent").innerHTML = html; openModal("#infoModal");
}
function showWishlist() {
  const items = state.products.filter(p => state.wishlist.has(p._id));
  openInfo("Your wishlist", items.length ? `<div class="drawer-items">${items.map(p => `<div class="cart-line"><img src="${escapeHtml(p.images?.[0]||imageFallback)}" alt=""><div><h3>${escapeHtml(p.name)}</h3><p>${money(p.price)}</p><button class="button button-dark" data-add="${p._id}">Add to bag</button></div><button class="remove-line" data-wishlist="${p._id}">×</button></div>`).join("")}</div>` : "<p>Your wishlist is empty. Sign in and save pieces you love.</p>");
}
function checkoutSummary(subtotal, shipping = subtotal >= 1999 ? 0 : 99, total = subtotal+shipping) {
  return `<div class="summary-row"><span>Subtotal</span><span>${money(subtotal)}</span></div><div class="summary-row"><span>Shipping</span><span>${shipping===0?"Complimentary":money(shipping)}</span></div><div class="summary-row total"><span>Estimated total</span><span>${money(total)}</span></div>`;
}
async function placeOrder(event) {
  event.preventDefault();
  const message = $("#checkoutMessage"); message.textContent = "";
  if (!state.user) { message.textContent = "Please sign in before placing your order."; return; }
  const items = cartProducts().map(p => ({ productId:p._id, quantity:p.quantity }));
  if (!items.length) { message.textContent = "Your bag is empty."; return; }
  const form = new FormData(event.currentTarget);
  const address = Object.fromEntries(form.entries());
  const button = $('button[type="submit"]', event.currentTarget); button.disabled = true; button.textContent = "Creating order…";
  try {
    const data = await api("/api/checkout", { method:"POST", body:JSON.stringify({ items, address }) });
    state.cart = []; saveCart(); closeModal();
    openInfo("Order created", `<p>Your order <strong>${escapeHtml(data.order.orderNumber)}</strong> has been created.</p><div class="checkout-summary">${checkoutSummary(data.order.subtotal,data.order.shipping,data.order.total)}</div><p><strong>Payment status: ${escapeHtml(data.order.paymentStatus)}.</strong></p><p>${escapeHtml(data.payment.message || "Payment order created. Complete payment using the configured provider before fulfilment.")}</p><p class="fine-print">This starter does not automatically fulfil supplier orders. Do not ship an order until payment is independently verified.</p>`);
  } catch (e) { message.textContent = e.message; }
  finally { button.disabled = false; button.textContent = "Create order"; }
}
async function submitAuth(event) {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const payload = Object.fromEntries(form.entries());
  $("#authMessage").textContent = "";
  try {
    const data = await api(`/api/auth/${state.authMode==="register"?"register":"login"}`, { method:"POST", body:JSON.stringify(payload) });
    state.user = data.user; await loadUser(); closeModal(); showToast(`Welcome${state.user?.name ? ", "+state.user.name.split(" ")[0] : ""}.`);
  } catch (e) { $("#authMessage").textContent = e.message; }
}
document.addEventListener("click", async event => {
  const add = event.target.closest("[data-add]");
  if (add) {
    const p = state.products.find(p => p._id === add.dataset.add);
    if (p) {
      const line = state.cart.find(x => x.productId === p._id);
      if (p.stock < 1) return showToast("This item is currently unavailable.");
      if (line) { if (line.quantity >= Math.min(10,p.stock)) return showToast("Maximum available quantity reached."); line.quantity++; }
      else state.cart.push({ productId:p._id, quantity:1 });
      saveCart(); showToast("Added to your bag.");
    }
  }
  const wish = event.target.closest("[data-wishlist]");
  if (wish) await toggleWishlist(wish.dataset.wishlist);
  const qty = event.target.closest("[data-qty]");
  if (qty) {
    const line = state.cart.find(x => x.productId === qty.dataset.qty);
    const p = state.products.find(x => x._id === qty.dataset.qty);
    if (line && p) { line.quantity += Number(qty.dataset.delta); if (line.quantity < 1) state.cart = state.cart.filter(x=>x.productId!==p._id); else line.quantity=Math.min(line.quantity,10,p.stock); saveCart(); }
  }
  const remove = event.target.closest("[data-remove]");
  if (remove) { state.cart = state.cart.filter(x=>x.productId!==remove.dataset.remove); saveCart(); }
  const category = event.target.closest("[data-category]");
  if (category) { state.category = category.dataset.category; $$(".category-pills .pill").forEach(b=>b.classList.toggle("active",b===category)); renderProducts(); }
  const tab = event.target.closest("[data-auth-tab]");
  if (tab) setAuthMode(tab.dataset.authTab);
  if (event.target.closest("#cartOpen")) openDrawer();
  if (event.target.closest(".close-drawer")) closeDrawer();
  if (event.target.id === "overlay") { closeDrawer(); closeModal(); }
  if (event.target.closest("[data-close-modal]")) closeModal();
  if (event.target.closest(".account-open")) { openModal("#accountModal"); if (state.user) await loadUser(); }
  if (event.target.closest("#wishlistOpen")) showWishlist();
  if (event.target.closest("#checkoutOpen")) {
    if (!state.cart.length) return showToast("Add a piece to your bag first.");
    $("#checkoutSummary").innerHTML = checkoutSummary(cartSubtotal());
    openModal("#checkoutModal");
    if (!state.user) { closeModal(); openModal("#accountModal"); showToast("Sign in or create an account before checkout."); }
  }
  if (event.target.closest("#searchToggle")) { $("#searchPanel").classList.toggle("hidden"); $("#searchInput").focus(); }
  if (event.target.closest("#searchSubmit")) { state.search=$("#searchInput").value.trim(); renderProducts(); $("#shop").scrollIntoView({behavior:"smooth"}); }
  if (event.target.closest("#menuToggle")) $("#mainNav").classList.toggle("open");
  if (event.target.closest("[data-category-link]")) {
    state.category=event.target.closest("[data-category-link]").dataset.categoryLink;
    $$(".category-pills .pill").forEach(b=>b.classList.toggle("active",b.dataset.category===state.category));
    renderProducts(); $("#mainNav").classList.remove("open");
  }
  if (event.target.closest("#logoutButton")) {
    try { await api("/api/auth/logout",{method:"POST",body:JSON.stringify({})}); state.user=null; await loadUser(); showToast("Signed out."); closeModal(); location.reload(); } catch(e){showToast(e.message);}
  }
  if (event.target.closest("#ordersOpen")) {
    try {
      const data=await api("/api/orders");
      const html=data.orders.length?data.orders.map(o=>`<div class="cart-line"><div><strong>${escapeHtml(o.orderNumber)}</strong><p>${new Date(o.createdAt).toLocaleDateString("en-IN")}</p><p>${escapeHtml(o.status)} · payment ${escapeHtml(o.payment?.status||"pending")}</p></div><strong>${money(o.total)}</strong></div>`).join(""):"<p>You have no orders yet.</p>";
      $("#accountExtra").innerHTML=html;
    } catch(e){showToast(e.message);}
  }
  if (event.target.closest("#newsletterForm button")) {}
  if (event.target.closest('a[href^="#"]')) {
    const href=event.target.closest('a[href^="#"]').getAttribute("href");
    const info={
      "#about":["About IVERSE","<p>IVERSE is a concept for modern essentials, selected with intention. Update this section with your real business story before launch.</p>"],
      "#contact":["Contact us","<p>Add your monitored customer-support email and business contact details before launch. Do not publish placeholder contact details.</p>"],
      "#shipping":["Shipping information","<p>Shipping estimates vary by product and supplier. Confirm dispatch times, tracking, delivery areas, and shipping charges before publishing a final policy.</p>"],
      "#returns":["Returns & refunds","<p>Publish a clear, legally reviewed return and refund policy that matches your supplier agreements and applicable Indian consumer-protection requirements.</p>"],
      "#faq":["Frequently asked questions","<h3>When will my order arrive?</h3><p>Delivery estimates should be confirmed for each product and delivery PIN code.</p><h3>How can I contact support?</h3><p>Add your verified customer-support contact information before launch.</p>"],
      "#privacy":["Privacy policy","<p>Replace this starter text with a privacy policy describing what data you collect, why you collect it, retention, processors, and customer rights.</p>"],
      "#terms":["Terms of service","<p>Replace this starter text with terms reviewed for your business and jurisdiction before accepting real orders.</p>"]
    };
    if(info[href]) { event.preventDefault(); openInfo(info[href][0],info[href][1]); }
  }
});
$("#sortSelect").addEventListener("change", event => { state.sort=event.target.value; renderProducts(); });
$("#searchInput").addEventListener("keydown", event => { if(event.key==="Enter") $("#searchSubmit").click(); });
$("#checkoutForm").addEventListener("submit", placeOrder);
$("#authForm").addEventListener("submit", submitAuth);
$("#newsletterForm").addEventListener("submit", async event => {
  event.preventDefault(); const email=$("#newsletterEmail").value;
  try { const data=await api("/api/newsletter",{method:"POST",body:JSON.stringify({email})}); $("#newsletterMessage").textContent=data.message; event.currentTarget.reset(); }
  catch(e){$("#newsletterMessage").textContent=e.message;}
});
document.addEventListener("keydown", event => { if(event.key==="Escape"){closeDrawer();closeModal();$("#mainNav").classList.remove("open");} });
$("#year").textContent=new Date().getFullYear();
(async function init(){ await loadProducts(); await loadUser(); renderCart(); })();
