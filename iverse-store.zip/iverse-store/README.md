# IVERSE — Luxury E-commerce Starter

A responsive luxury storefront and Express/MongoDB API starter. This is a foundation for development, not a certified production-ready store. The product catalogue is sample data; validate suppliers, stock, prices, product claims, policies, payments and deployment before accepting real orders.

## Requirements

- Node.js 20+
- MongoDB Community Server running locally, or a MongoDB Atlas connection string
- npm (included with Node.js)

## Run on Windows

1. Install Node.js LTS and MongoDB, or create a MongoDB Atlas cluster.
2. Open PowerShell in this project folder.
3. Copy the environment template:

   ```powershell
   Copy-Item .env.example .env
   ```

4. Edit `.env`. Set `MONGODB_URI` and replace `SESSION_SECRET` with a long random secret. Keep `.env` private.
5. Install dependencies and seed the sample products:

   ```powershell
   npm install
   npm run seed
   npm start
   ```

6. Open `http://localhost:3000`.

For automatic restart during development, run `npm run dev`.

## Sample catalogue

`npm run seed` inserts eight sample products and a `WELCOME10` coupon if they do not already exist. Images use remote Unsplash URLs; replace them with images you have rights to use and verify they match the products you actually sell.

## Authentication / admin

- Registration and login use bcrypt password hashes and server-side sessions.
- No default admin account is created.
- To bootstrap a new admin, temporarily set `BOOTSTRAP_ADMIN_EMAIL` in `.env` to the email that will register, register that email, then remove `BOOTSTRAP_ADMIN_EMAIL` and restart. Do this only on a private, trusted local instance before opening the site publicly. For an existing deployment, implement a one-time protected admin promotion procedure instead.
- Do not leave the bootstrap variable set on a public deployment; anyone registering that email while it is configured could gain admin access.
- The current starter uses sessions and SameSite=Lax cookies. Before public launch, add a complete CSRF strategy for every state-changing route, configure production session storage, audit dependencies, and test security headers and session settings.

## Payment setup

Without Razorpay credentials, checkout creates a **pending unpaid order only**. It does not take payment and must not trigger fulfilment.

For Razorpay test mode:
1. Create a Razorpay account and use TEST API credentials.
2. Set `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, and a webhook secret in `.env`.
3. Configure the webhook URL to `/api/payments/razorpay/webhook` and subscribe to `payment.captured`.
4. Implement the Razorpay Checkout.js client flow using the returned payment order, then post its response to `/api/payments/razorpay/verify`. This starter has the server-side order creation and signature verification endpoints, but the client-side payment widget is intentionally not presented as complete. Do not switch to live mode until the full payment flow and webhook behavior have been tested end-to-end.
5. Use test keys only while testing. Never put secret keys in browser JavaScript.

The payment webhook is a foundation, not a substitute for testing retries, duplicate events, refunds, payment failures, order/payment reconciliation, and stock reservation. In production, use provider API verification where appropriate and robust idempotency.

## API overview

- `GET /api/health` — app/database/payment configuration status
- `GET /api/products?q=&category=&sort=` — active product catalogue
- `GET /api/products/:slug` — product details
- `POST /api/auth/register` — register `{name,email,password}`
- `POST /api/auth/login` — login `{email,password}`
- `GET /api/auth/me` — current session user
- `POST /api/auth/logout` — destroy session
- `GET /api/wishlist` — authenticated wishlist
- `POST /api/wishlist/:productId` — toggle wishlist item
- `GET /api/orders` — authenticated customer's orders
- `POST /api/coupons/validate` — validate `{code,subtotal}`
- `POST /api/newsletter` — subscribe `{email}`
- `POST /api/checkout` — authenticated order creation `{items:[{productId,quantity}],address:{fullName,phone,line1,line2,city,state,postalCode}}`
- `POST /api/payments/razorpay/verify` — verify Razorpay signature
- `POST /api/payments/razorpay/webhook` — webhook signature verification
- `GET /api/admin/products` — admin product list
- `POST /api/admin/products` — admin create product
- `PATCH /api/admin/products/:id` — admin update product
- `DELETE /api/admin/products/:id` — soft-disable product
- `GET /api/admin/orders` — admin order list
- `PATCH /api/admin/orders/:id/status` — admin order status update

All admin endpoints require an authenticated session with role `admin`.

## Current limitations — must address before launch

- No client-side Razorpay Checkout.js flow is implemented, so online payment is not end-to-end.
- No automatic supplier integration or inventory synchronization; supplier fields are placeholders.
- The coupon validation endpoint is present but coupon application is not yet wired into checkout.
- Product reviews/ratings are intentionally omitted rather than fabricated.
- Product pages are represented through catalogue cards in this MVP; dedicated detail routes and variant selection remain to be built.
- Legal, shipping, returns and contact sections are placeholders and must be replaced with accurate business information.
- Image URLs are external and need validation/licensing.
- Add automated tests, CSRF protection, production logging/monitoring, transactional stock management, idempotent order/payment processing, password reset/email verification, accessible form validation, and a security review before public launch.
- Add privacy-conscious analytics only if needed and disclose them appropriately.

## Deployment checklist

1. Create a production MongoDB database and least-privilege database user.
2. Deploy Node app to a trusted Node.js host.
3. Set `NODE_ENV=production`, `BASE_URL`, `MONGODB_URI`, a strong `SESSION_SECRET`, and provider credentials through the host's secret manager.
4. Use HTTPS; ensure `secure` cookies are enabled and `trust proxy` matches the host.
5. Remove admin bootstrap configuration.
6. Configure domain DNS and TLS; check `iverse.in` availability with an accredited registrar before purchasing.
7. Configure Razorpay webhooks and test payment success/failure, webhook retries and duplicate events.
8. Confirm supplier contracts, product quality, actual delivery timelines, tax/invoice obligations, refund workflow, customer support and applicable Indian legal requirements.
9. Run a full security and functional test pass before accepting customer orders.
